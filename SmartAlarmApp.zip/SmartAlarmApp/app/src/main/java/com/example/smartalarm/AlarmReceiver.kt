package com.example.smartalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getStringExtra("alarm_id") ?: "default"
        val prefs = context.getSharedPreferences("alarms", Context.MODE_PRIVATE)
        if (id != "default" && !prefs.getBoolean("enabled_$id", false)) return

        ContextCompat.startForegroundService(
            context, Intent(context, AlarmService::class.java).putExtra("alarm_id", id)
        )
        // Re-arm for the next day so the alarm repeats daily.
        if (prefs.contains("hour_$id")) {
            AlarmScheduler.schedule(context, id, prefs.getInt("hour_$id", 7), prefs.getInt("minute_$id", 0))
        }
    }
}
