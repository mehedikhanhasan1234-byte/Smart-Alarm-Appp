package com.example.smartalarm

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.CountDownTimer
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class AlarmActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var timerText: TextView
    private lateinit var cameraExecutor: ExecutorService
    private var timer: CountDownTimer? = null
    private var remainingMs = 120_000L
    @Volatile private var faceAndEyesVisible = false
    @Volatile private var blinkSeen = false
    @Volatile private var eyesWereOpen = false
    @Volatile private var processing = false
    private var cameraStarted = false

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else status.text = "ক্যামেরার অনুমতি প্রয়োজন। অ্যালার্ম বাজতে থাকবে।"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        cameraExecutor = Executors.newSingleThreadExecutor()

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF101827.toInt()) }
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        val panel = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xCC101827.toInt())
        }
        val heading = TextView(this).apply {
            text = "Smart Alarm App"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val emergency = android.widget.Button(this).apply {
            text = "জরুরি বন্ধ (চেপে ধরে রাখো)"
            setOnLongClickListener {
                stopService(android.content.Intent(this@AlarmActivity, AlarmService::class.java))
                finish()
                true
            }
        }
        status = TextView(this).apply {
            text = "ক্যামেরার সামনে থাকো এবং চোখের পলক ফেলো"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 12, 0, 8)
        }
        timerText = TextView(this).apply {
            text = "সময় বাকি: 02:00"
            textSize = 20f
            setTextColor(0xFFB9F6CA.toInt())
        }
        panel.addView(heading)
        panel.addView(status)
        panel.addView(timerText)
        panel.addView(emergency)
        val params = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = android.view.Gravity.BOTTOM
            setMargins(16, 16, 16, 24)
        }
        root.addView(panel, params)
        setContentView(root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        if (cameraStarted) return
        cameraStarted = true
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val options = FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .enableTracking()
                .build()
            val detector = FaceDetection.getClient(options)
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(cameraExecutor) { proxy ->
                val mediaImage = proxy.image
                if (mediaImage == null || processing) {
                    proxy.close()
                } else {
                    processing = true
                    val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
                    detector.process(image)
                        .addOnSuccessListener { faces -> handleFaces(faces) }
                        .addOnFailureListener { faceAndEyesVisible = false }
                        .addOnCompleteListener {
                            processing = false
                            proxy.close()
                        }
                }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis
                )
            } catch (e: Exception) {
                status.text = "ক্যামেরা চালু করা যায়নি। অ্যালার্ম বাজতে থাকবে।"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handleFaces(faces: List<Face>) {
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
        if (face == null) {
            faceAndEyesVisible = false
            runOnUiThread { status.text = "মুখ দেখা যাচ্ছে না—ক্যামেরার সামনে থাকো" }
            return
        }
        val left = face.leftEyeOpenProbability
        val right = face.rightEyeOpenProbability
        if (left != null && right != null) {
            val bothOpen = left > 0.65f && right > 0.65f
            val eitherClosed = left < 0.35f || right < 0.35f
            val blinkWasSeen = blinkSeen
            if (eyesWereOpen && eitherClosed) blinkSeen = true
            eyesWereOpen = bothOpen
            faceAndEyesVisible = bothOpen
            runOnUiThread {
                status.text = when {
                    !blinkSeen -> "মুখ দেখা যাচ্ছে—একবার চোখের পলক ফেলো"
                    bothOpen -> "লাইভ যাচাই চলছে… সামনে তাকিয়ে থাকো"
                    else -> "চোখ খুলে ক্যামেরার দিকে তাকাও"
                }
                if (blinkSeen && bothOpen && (!blinkWasSeen || timer == null)) {
                    startVerificationTimer()
                }
            }
        } else {
            faceAndEyesVisible = false
            runOnUiThread { status.text = "চোখ শনাক্ত হচ্ছে না—আলো বাড়াও" }
        }
    }

    private fun startVerificationTimer() {
        if (timer != null || !blinkSeen || !faceAndEyesVisible) return
        timer = object : CountDownTimer(120_000L, 250L) {
            override fun onTick(millisUntilFinished: Long) {
                if (!faceAndEyesVisible || !blinkSeen) {
                    cancel()
                    timer = null
                    runOnUiThread {
                        timerText.text = "সময় বাকি: 02:00"
                        status.text = "মুখ ও চোখ ক্যামেরায় রাখো—সময় আবার শুরু হবে"
                    }
                    return
                }
                val seconds = (millisUntilFinished / 1000).toInt()
                runOnUiThread { timerText.text = "সময় বাকি: %02d:%02d".format(seconds / 60, seconds % 60) }
            }

            override fun onFinish() {
                timer = null
                if (faceAndEyesVisible && blinkSeen) {
                    stopService(android.content.Intent(this@AlarmActivity, AlarmService::class.java))
                    Toast.makeText(this@AlarmActivity, "যাচাই সফল! অ্যালার্ম বন্ধ হয়েছে।", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    runOnUiThread { timerText.text = "সময় বাকি: 02:00" }
                }
            }
        }.start()
    }

    override fun onDestroy() {
        timer?.cancel()
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
        super.onDestroy()
    }
}
