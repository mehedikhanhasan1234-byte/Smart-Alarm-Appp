package com.example.smartalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {
    private fun pending(context: Context, id: String): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).putExtra("alarm_id", id)
        return PendingIntent.getBroadcast(
            context, id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun nextTrigger(hour: Int, minute: Int): Long =
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis

    fun schedule(context: Context, id: String, hour: Int, minute: Int) {
        val pi = pending(context, id)
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.setAlarmClock(AlarmManager.AlarmClockInfo(nextTrigger(hour, minute), pi), pi)
    }

    fun cancel(context: Context, id: String) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.cancel(pending(context, id))
    }

    /** Re-arms every enabled alarm (used after reboot). */
    fun rescheduleAll(context: Context) {
        val prefs = context.getSharedPreferences("alarms", Context.MODE_PRIVATE)
        val ids = prefs.getStringSet("ids", emptySet()) ?: emptySet()
        for (id in ids) {
            if (prefs.getBoolean("enabled_$id", true)) {
                schedule(context, id, prefs.getInt("hour_$id", 7), prefs.getInt("minute_$id", 0))
            }
        }
    }
}
