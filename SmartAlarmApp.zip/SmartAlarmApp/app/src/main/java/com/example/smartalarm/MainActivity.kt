package com.example.smartalarm

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var listContainer: LinearLayout
    private lateinit var timePicker: TimePicker
    private val prefs by lazy { getSharedPreferences("alarms", Context.MODE_PRIVATE) }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(0xFF101827.toInt())
        }
        val title = TextView(this).apply {
            text = "Smart Alarm App"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val description = TextView(this).apply {
            text = "একাধিক অ্যালার্ম যোগ করো। প্রতিটি অ্যালার্মের সময় আলাদা করে সেট করা যাবে।"
            textSize = 16f
            setTextColor(0xFFD7DEEA.toInt())
            setPadding(0, 12, 0, 14)
        }
        timePicker = TimePicker(this).apply { setIs24HourView(true) }

        val addButton = Button(this).apply {
            text = "+ অ্যালার্ম যোগ করো"
            setOnClickListener { addAlarm() }
        }
        val listTitle = TextView(this).apply {
            text = "তোমার অ্যালার্মগুলো"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 18, 0, 8)
        }
        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(listContainer) }

        root.addView(title)
        root.addView(description)
        root.addView(timePicker)
        root.addView(addButton)
        root.addView(listTitle)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        renderAlarms()
    }

    private fun alarmIds(): Set<String> =
        prefs.getStringSet("ids", emptySet())?.toSet() ?: emptySet()

    private fun addAlarm() {
        val id = System.currentTimeMillis().toString()
        val hour = timePicker.hour
        val minute = timePicker.minute
        val ids = alarmIds().toMutableSet().apply { add(id) }
        prefs.edit()
            .putStringSet("ids", ids)
            .putInt("hour_$id", hour)
            .putInt("minute_$id", minute)
            .putBoolean("enabled_$id", true)
            .apply()
        AlarmScheduler.schedule(this, id, hour, minute)
        Toast.makeText(this, "অ্যালার্ম যোগ হয়েছে: %02d:%02d".format(hour, minute), Toast.LENGTH_SHORT).show()
        renderAlarms()
    }

    private fun cancel(id: String) {
        AlarmScheduler.cancel(this, id)
        val ids = alarmIds().toMutableSet().apply { remove(id) }
        prefs.edit().putStringSet("ids", ids).remove("hour_$id").remove("minute_$id")
            .remove("enabled_$id").apply()
        renderAlarms()
    }

    private fun renderAlarms() {
        if (!::listContainer.isInitialized) return
        listContainer.removeAllViews()
        val ids = alarmIds().sortedBy { id ->
            prefs.getInt("hour_$id", 0) * 60 + prefs.getInt("minute_$id", 0)
        }
        if (ids.isEmpty()) {
            listContainer.addView(TextView(this).apply {
                text = "এখনো কোনো অ্যালার্ম যোগ করা হয়নি।"
                setTextColor(0xFFD7DEEA.toInt())
                setPadding(0, 8, 0, 8)
            })
        }
        ids.forEach { id ->
            val hour = prefs.getInt("hour_$id", 7)
            val minute = prefs.getInt("minute_$id", 0)
            val enabled = prefs.getBoolean("enabled_$id", true)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(0xFF202B3C.toInt())
            }
            val time = TextView(this).apply {
                text = "%02d:%02d".format(hour, minute) + if (enabled) "  • চালু" else "  • বন্ধ"
                textSize = 23f
                setTextColor(0xFFFFFFFF.toInt())
            }
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
            val toggle = Button(this).apply {
                text = if (enabled) "বন্ধ করো" else "চালু করো"
                setOnClickListener {
                    val newEnabled = !prefs.getBoolean("enabled_$id", true)
                    prefs.edit().putBoolean("enabled_$id", newEnabled).apply()
                    if (newEnabled) AlarmScheduler.schedule(this@MainActivity, id, hour, minute)
                    else AlarmScheduler.cancel(this@MainActivity, id)
                    renderAlarms()
                }
            }
            val delete = Button(this).apply {
                text = "মুছুন"
                setOnClickListener { cancel(id) }
            }
            buttons.addView(toggle)
            buttons.addView(delete)
            row.addView(time)
            row.addView(buttons)
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 10 }
            listContainer.addView(row, params)
        }
    }
}
