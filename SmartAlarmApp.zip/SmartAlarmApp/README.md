# Smart Alarm App (Android / Kotlin)

## What this starter project does
- Lets the user add multiple independent alarms at different times.
- Schedules exact alarms with Android AlarmManager; each alarm can be toggled or deleted.
- Starts a foreground media-playback service that loops the default alarm tone.
- Uses the front camera and Google ML Kit face detection in the alarm screen.
- Requires a face, open-eye detection, and at least one detected blink; the user must remain in view for two minutes for the alarm to stop.

## Build and run
1. Install Android Studio on a computer (Android Studio is not normally used to compile a full native project directly on a phone).
2. Extract `SmartAlarmApp.zip`.
3. In Android Studio, choose **Open** and select the extracted `SmartAlarmApp` folder.
4. Let Gradle sync and download dependencies. Use JDK 17 if Android Studio asks.
5. Connect an Android phone with USB debugging enabled, or create an emulator. Press **Run**.
6. On the phone, allow notifications and camera permission.
7. Open **Exact Alarm permission settings** in the app and enable the permission if Android requests it.
8. Add two or more alarms a few minutes ahead to test; use each row's toggle/delete buttons.

## Important limitations
- This is a starter project, not a production-tested APK. It requires Android Studio/Gradle to build.
- Android versions and manufacturers differ in full-screen alarm notification behavior. The system may show a notification instead of automatically opening the alarm screen.
- Camera verification only runs while the alarm screen is visible. If the user leaves the screen, locks the phone, or another app covers it, verification may pause; the alarm service should keep ringing but test this on the target phone.
- ML Kit blink detection is a heuristic, not secure liveness detection. It can fail in dim light, with glasses, or on some faces; it cannot reliably prove that a person is awake.
- Exact alarms and notifications require user permissions on newer Android versions.
- For production, add reboot rescheduling, battery-optimization guidance, handling for missing alarm tone, a manual emergency stop, and device-specific testing.
